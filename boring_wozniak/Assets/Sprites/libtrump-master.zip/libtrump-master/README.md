# LIBTRUMP
A library of over a hundred Donald Trump soundclips, labeled with he says in the sound clip.
DJs, AI/Natural Language Processing people and all others welcome to use, mix, remix.

also, thanks to [Ben Weinfeld](https://github.com/sudonotpseudo) and Arthur Rafal of the [Trump Prank Call](https://github.com/sudonotpseudo/hackruix) app at HackRU. Awesome guys.
